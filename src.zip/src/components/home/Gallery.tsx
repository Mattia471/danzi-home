import { ArrowUpRight } from 'lucide-react';
import { gallery } from '@/data/property';
import { Container } from '@/components/ui/Container';
import { SectionHeading } from '@/components/ui/SectionHeading';

export function Gallery() {
  return (
    <section className="bg-cream py-20 lg:py-28">
      <Container>
        <div className="flex flex-col gap-7 md:flex-row md:items-end md:justify-between">
          <SectionHeading eyebrow="Dentro D’Anzi House" title="Spazi luminosi, veri, da usare davvero." text="Niente ambienti da fotografare e basta: cucina, living, camera e terrazza sono pensati per farti stare bene anche nei soggiorni più lunghi." />
          <div className="hidden h-16 w-16 shrink-0 items-center justify-center rounded-full bg-sage text-white md:flex"><ArrowUpRight size={25}/></div>
        </div>
        <div className="mt-12 grid auto-rows-[210px] gap-4 sm:grid-cols-2 lg:grid-cols-12 lg:auto-rows-[230px]">
          {gallery.map((item, i) => (
            <figure key={item.label} className={`group relative overflow-hidden rounded-[1.8rem] bg-white ${i === 0 ? 'sm:row-span-2 lg:col-span-7 lg:row-span-2' : i === 1 ? 'lg:col-span-5' : 'lg:col-span-5'}`}>
              <img src={item.src} alt={item.alt} className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.04]" />
              <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black/50 to-transparent" />
              <figcaption className="absolute bottom-4 left-4 rounded-full bg-white px-4 py-2 text-xs font-extrabold text-ink shadow-sm">{item.label}</figcaption>
            </figure>
          ))}
        </div>
      </Container>
    </section>
  );
}
