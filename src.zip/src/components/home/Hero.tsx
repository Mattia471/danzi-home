import { ArrowRight, MapPin, Star } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Container } from '@/components/ui/Container';
import { property } from '@/data/property';

export function Hero() {
  return (
    <section className="relative bg-white px-3 pb-5 pt-3 sm:px-5">
      <div className="relative min-h-[76vh] overflow-hidden rounded-[2rem] bg-ink sm:rounded-[2.6rem] lg:min-h-[82vh]">
        <img src="/images/hero.svg" alt="D'Anzi House" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/35 to-black/5" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-black/10" />

        <Container className="relative flex min-h-[76vh] flex-col justify-end pb-28 pt-24 text-white lg:min-h-[82vh] lg:pb-32">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/12 px-4 py-2 text-xs font-bold backdrop-blur-md">
              <MapPin size={14} /> Roma · Monte Mario · Gemelli
            </div>
            <h1 className="display-title mt-6 max-w-[900px] text-white">Una casa bella da vivere. Anche quando sei qui per altro.</h1>
            <p className="mt-6 max-w-2xl text-base font-medium leading-8 text-white/80 md:text-lg">
              D’Anzi House è il tuo spazio a Roma per soggiorni di cura, lavoro e studio: indipendente, luminoso, con una terrazza privata che cambia il ritmo delle giornate.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button to="/prenota">Verifica le date <ArrowRight className="ml-2" size={17} /></Button>
              <Button to="/la-casa" variant="light">Scopri gli spazi</Button>
            </div>
          </div>

          <div className="absolute bottom-6 right-5 hidden items-center gap-3 rounded-2xl border border-white/20 bg-black/25 px-4 py-3 backdrop-blur-md sm:flex lg:right-10">
            <span className="flex items-center gap-1 text-sm font-extrabold"><Star size={15} fill="currentColor" /> {property.rating}</span>
            <span className="h-5 w-px bg-white/25" />
            <span className="text-xs font-semibold text-white/75">{property.reviews} recensioni · Superhost</span>
          </div>
        </Container>

        <div className="absolute right-5 top-5 hidden rounded-[1.4rem] bg-sun px-5 py-4 text-ink shadow-card md:block">
          <p className="text-[10px] font-extrabold uppercase tracking-[0.19em]">Il suo spazio speciale</p>
          <p className="mt-1 font-display text-2xl font-extrabold tracking-tight">90 m² di terrazza privata</p>
        </div>
      </div>
    </section>
  );
}
