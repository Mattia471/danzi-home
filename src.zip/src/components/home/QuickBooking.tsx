import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, CalendarDays, Users } from 'lucide-react';
import { Container } from '@/components/ui/Container';

export function QuickBooking() {
  const navigate = useNavigate();
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState('2');

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const q = new URLSearchParams({ checkIn, checkOut, guests });
    navigate(`/prenota?${q.toString()}`);
  };

  return (
    <section className="relative z-20 -mt-16 pb-8 lg:-mt-20">
      <Container>
        <form onSubmit={submit} className="grid gap-2 rounded-[1.8rem] border border-black/5 bg-white p-3 shadow-card md:grid-cols-[1fr_1fr_0.62fr_auto] md:items-end md:p-4">
          <label className="block rounded-2xl px-3 py-2 transition hover:bg-cream">
            <span className="mb-2 flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.18em] text-ink/45"><CalendarDays size={14}/> Check-in</span>
            <input required type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} className="w-full border-0 bg-transparent p-0 text-sm font-bold outline-none" />
          </label>
          <label className="block rounded-2xl px-3 py-2 transition hover:bg-cream">
            <span className="mb-2 flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.18em] text-ink/45"><CalendarDays size={14}/> Check-out</span>
            <input required type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} className="w-full border-0 bg-transparent p-0 text-sm font-bold outline-none" />
          </label>
          <label className="block rounded-2xl px-3 py-2 transition hover:bg-cream">
            <span className="mb-2 flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.18em] text-ink/45"><Users size={14}/> Ospiti</span>
            <select className="w-full border-0 bg-transparent p-0 text-sm font-bold outline-none" value={guests} onChange={(e) => setGuests(e.target.value)}>{[1,2,3,4].map(n => <option key={n} value={n}>{n}</option>)}</select>
          </label>
          <button className="flex min-h-[58px] items-center justify-center gap-2 rounded-[1.2rem] bg-sage px-7 text-sm font-extrabold text-white shadow-[0_12px_30px_rgba(255,104,70,0.25)] transition hover:-translate-y-0.5 hover:bg-clay">Controlla <ArrowRight size={17}/></button>
        </form>
      </Container>
    </section>
  );
}
