import { Instagram, MapPin, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Container } from '@/components/ui/Container';
import { property } from '@/data/property';

export function Footer() {
  return (
    <footer className="bg-[#111] py-14 text-white">
      <Container>
        <div className="mb-12 rounded-[2rem] bg-sage px-6 py-8 text-white md:flex md:items-center md:justify-between md:px-9">
          <div>
            <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-white/70">Hai già le date?</p>
            <p className="mt-2 font-display text-3xl font-extrabold tracking-tight md:text-4xl">Controlla la disponibilità in pochi secondi.</p>
          </div>
          <Link to="/prenota" className="mt-6 inline-flex rounded-full bg-white px-6 py-3.5 text-sm font-extrabold text-ink transition hover:-translate-y-0.5 md:mt-0">Verifica le date</Link>
        </div>
        <div className="grid gap-10 md:grid-cols-[1.3fr_1fr_1fr]">
          <div>
            <p className="font-display text-4xl font-extrabold tracking-[-0.04em]">D’Anzi House<span className="text-sage">.</span></p>
            <p className="mt-4 max-w-md text-sm leading-7 text-white/55">Una casa a Roma Monte Mario per chi ha bisogno di un posto bello, pratico e semplice da vivere.</p>
          </div>
          <div className="space-y-3 text-sm text-white/65">
            <p className="font-extrabold text-white">Contatti</p>
            <p className="flex items-center gap-2"><MapPin size={15} /> {property.address}</p>
            <a href={`tel:${property.phone.replace(/\s/g, '')}`} className="flex items-center gap-2 hover:text-white"><Phone size={15} /> {property.phone}</a>
          </div>
          <div className="space-y-3 text-sm text-white/65">
            <p className="font-extrabold text-white">Informazioni</p>
            <Link className="block hover:text-white" to="/privacy">Privacy & Cookie</Link>
            <a className="block hover:text-white" href={property.airbnbUrl} target="_blank" rel="noreferrer">Annuncio Airbnb</a>
          </div>
        </div>
        <div className="mt-12 flex flex-col gap-4 border-t border-white/10 pt-7 text-xs text-white/40 sm:flex-row sm:items-center sm:justify-between">
          <span>© {new Date().getFullYear()} D’Anzi House. Tutti i diritti riservati.</span>
          <a href="https://www.instagram.com/mattiacucuzza_/" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 transition hover:text-white"><Instagram size={14} /> Sito sviluppato da @mattiacucuzza_</a>
        </div>
      </Container>
    </footer>
  );
}
