import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Container } from '@/components/ui/Container';

const links = [
  ['La casa', '/la-casa'],
  ['Posizione', '/posizione'],
  ['Prenota', '/prenota'],
];

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-black/5 bg-white/90 backdrop-blur-xl">
      <Container className="flex h-[76px] items-center justify-between">
        <Link to="/" className="leading-none" onClick={() => setOpen(false)}>
          <span className="block font-display text-[1.72rem] font-extrabold tracking-[-0.04em]">D’Anzi House<span className="text-sage">.</span></span>
          <span className="mt-1 block text-[8px] font-extrabold uppercase tracking-[0.24em] text-ink/45">Roma · Monte Mario</span>
        </Link>
        <nav className="hidden items-center gap-8 md:flex">
          {links.map(([label, to]) => (
            <NavLink key={to} to={to} className={({ isActive }) => `text-sm font-bold transition ${isActive ? 'text-sage' : 'text-ink/65 hover:text-ink'}`}>{label}</NavLink>
          ))}
          <Link to="/prenota" className="rounded-full bg-sage px-5 py-3 text-sm font-extrabold text-white shadow-[0_8px_22px_rgba(255,104,70,0.22)] transition hover:-translate-y-0.5 hover:bg-clay">Verifica disponibilità</Link>
        </nav>
        <button className="rounded-full border border-black/10 bg-white p-3 md:hidden" onClick={() => setOpen((v) => !v)} aria-label="Apri menu">
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </Container>
      {open && (
        <div className="border-t border-black/5 bg-white md:hidden">
          <Container className="flex flex-col gap-2 py-5">
            {links.map(([label, to]) => <Link key={to} to={to} onClick={() => setOpen(false)} className="rounded-2xl px-3 py-4 font-bold hover:bg-cream">{label}</Link>)}
          </Container>
        </div>
      )}
    </header>
  );
}
