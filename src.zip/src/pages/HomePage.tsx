import { ArrowRight, HeartHandshake, MapPin, Star } from 'lucide-react';
import { Hero } from '@/components/home/Hero';
import { QuickBooking } from '@/components/home/QuickBooking';
import { Gallery } from '@/components/home/Gallery';
import { Container } from '@/components/ui/Container';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Button } from '@/components/ui/Button';
import { amenities, audiences, property } from '@/data/property';

const audienceStyles = [
  'bg-sage text-white',
  'bg-sun text-ink',
  'bg-cocoa text-white',
];

export function HomePage() {
  return (
    <>
      <Hero />
      <QuickBooking />

      <section className="pb-16 pt-8">
        <Container>
          <div className="flex gap-3 overflow-x-auto pb-2 md:grid md:grid-cols-4 lg:grid-cols-8 md:overflow-visible">
            {amenities.map(({ icon: Icon, label }) => (
              <div key={label} className="min-w-[132px] rounded-[1.35rem] border border-black/8 bg-white p-4 text-left transition hover:-translate-y-1 hover:shadow-card md:min-w-0">
                <Icon size={20} className="text-sage"/>
                <p className="mt-5 text-xs font-bold leading-5">{label}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20 lg:py-28">
        <Container>
          <div className="grid gap-10 lg:grid-cols-[0.75fr_1.25fr] lg:items-end">
            <div>
              <p className="eyebrow">Non il solito alloggio</p>
              <h2 className="section-title mt-4">Un posto che funziona con la tua giornata.</h2>
            </div>
            <p className="max-w-2xl text-base leading-8 text-ink/60 lg:justify-self-end">Che tu sia a Roma per un familiare, per un turno in ospedale o per l’università, qui trovi autonomia, spazio e un ambiente che non ti ricorda continuamente di essere “fuori casa”.</p>
          </div>

          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {audiences.map((item, i) => (
              <article key={item.title} className={`group min-h-[330px] rounded-[2rem] p-7 transition duration-300 hover:-translate-y-1.5 md:p-8 ${audienceStyles[i]}`}>
                <div className="flex items-start justify-between">
                  <span className="text-xs font-extrabold uppercase tracking-[0.2em] opacity-65">0{i + 1}</span>
                  <ArrowRight className="transition group-hover:translate-x-1" size={20}/>
                </div>
                <div className="mt-24">
                  <h3 className="font-display text-3xl font-extrabold tracking-tight">{item.title}</h3>
                  <p className="mt-4 text-sm font-medium leading-7 opacity-75">{item.text}</p>
                </div>
              </article>
            ))}
          </div>
        </Container>
      </section>

      <Gallery />

      <section className="bg-white py-20 lg:py-28">
        <Container className="grid gap-6 lg:grid-cols-[1.05fr_0.95fr]">
          <div className="relative min-h-[520px] overflow-hidden rounded-[2.2rem] bg-cocoa p-7 text-white md:p-12">
            <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-sage/35 blur-2xl" />
            <div className="relative">
              <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-sun">Roma · Monte Mario</p>
              <h2 className="mt-4 max-w-2xl font-display text-5xl font-extrabold leading-[0.95] tracking-[-0.045em] md:text-6xl">Vicino a ciò che conta. Lontano dal caos che non serve.</h2>
              <p className="mt-6 max-w-xl text-sm leading-7 text-white/65">Gemelli, San Filippo Neri, Università Cattolica e servizi di quartiere: D’Anzi House nasce in una zona residenziale comoda da vivere, non solo da visitare.</p>
              <Button to="/posizione" variant="light" className="mt-8">Scopri la zona <ArrowRight className="ml-2" size={17}/></Button>
            </div>
            <div className="absolute bottom-7 left-7 right-7 grid gap-3 sm:grid-cols-3 md:left-12 md:right-12">
              <div className="rounded-2xl border border-white/12 bg-white/8 p-4 backdrop-blur"><HeartHandshake size={20}/><p className="mt-5 text-lg font-extrabold">Ospitalità attenta</p></div>
              <div className="rounded-2xl border border-white/12 bg-white/8 p-4 backdrop-blur"><Star size={20}/><p className="mt-5 text-lg font-extrabold">{property.rating}/5</p></div>
              <div className="rounded-2xl border border-white/12 bg-white/8 p-4 backdrop-blur"><MapPin size={20}/><p className="mt-5 text-lg font-extrabold">Via Dego 4</p></div>
            </div>
          </div>

          <div className="grid gap-6">
            <div className="rounded-[2.2rem] bg-sun p-7 md:p-9">
              <p className="text-xs font-extrabold uppercase tracking-[0.19em] text-ink/55">Il plus che senti davvero</p>
              <p className="mt-5 font-display text-5xl font-extrabold leading-none tracking-[-0.05em]">90 m²</p>
              <p className="mt-3 text-lg font-bold">di terrazza privata</p>
              <p className="mt-5 text-sm leading-7 text-ink/65">Colazione fuori, una pausa al sole, una cena tranquilla. Non è un dettaglio decorativo: è spazio in più per vivere meglio.</p>
            </div>
            <div className="rounded-[2.2rem] bg-cream p-7 md:p-9">
              <p className="eyebrow">Recensioni</p>
              <p className="mt-5 font-display text-4xl font-extrabold tracking-tight">“Pulita, comoda, accogliente.”</p>
              <p className="mt-4 text-sm leading-7 text-ink/60">La fiducia degli ospiti Airbnb diventa parte del sito, senza trasformarlo in una copia di Airbnb.</p>
              <div className="mt-7 flex items-center gap-3 text-sm font-extrabold"><Star size={17} fill="currentColor" className="text-sage" /> {property.rating}/5 · {property.reviews} recensioni</div>
            </div>
          </div>
        </Container>
      </section>

      <section className="px-3 pb-3 sm:px-5 sm:pb-5">
        <div className="overflow-hidden rounded-[2rem] bg-sage py-20 text-white sm:rounded-[2.6rem]">
          <Container className="text-center">
            <p className="text-xs font-extrabold uppercase tracking-[0.22em] text-white/65">D’Anzi House · Roma</p>
            <h2 className="mx-auto mt-4 max-w-4xl font-display text-5xl font-extrabold leading-[0.95] tracking-[-0.05em] md:text-7xl">Hai trovato le date. Ora trova il tuo spazio.</h2>
            <p className="mx-auto mt-6 max-w-xl text-sm leading-7 text-white/75">Controlla la disponibilità e invia la richiesta direttamente dal sito.</p>
            <Button to="/prenota" variant="light" className="mt-8">Verifica disponibilità <ArrowRight className="ml-2" size={17}/></Button>
          </Container>
        </div>
      </section>
    </>
  );
}
