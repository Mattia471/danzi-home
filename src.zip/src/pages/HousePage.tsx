import { Check, Sun } from 'lucide-react';
import { Container } from '@/components/ui/Container';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Button } from '@/components/ui/Button';
import { amenities, gallery } from '@/data/property';

export function HousePage() {
  return (
    <>
      <section className="bg-white px-3 pb-6 pt-3 sm:px-5">
        <div className="relative overflow-hidden rounded-[2rem] bg-ink sm:rounded-[2.6rem]">
          <img src="/images/living.svg" className="h-[66vh] w-full object-cover" alt="Living D'Anzi House"/>
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/25 to-transparent" />
          <Container className="absolute inset-0 flex items-end pb-10 text-white md:pb-14">
            <div className="max-w-3xl">
              <p className="text-xs font-extrabold uppercase tracking-[0.22em] text-sun">Dentro D’Anzi House</p>
              <h1 className="display-title mt-4 text-white">Una casa semplice da vivere, bella da ritrovare.</h1>
            </div>
          </Container>
        </div>
      </section>

      <section className="py-20 lg:py-28">
        <Container className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
          <SectionHeading eyebrow="Spazi" title="Tutto quello che serve per stare bene anche più di qualche notte." text="La camera matrimoniale può essere preparata con letto king size 180×200 oppure, su richiesta, con due letti singoli. Il soggiorno dispone di divano letto matrimoniale, tavolo da pranzo e cucina completa." />
          <div className="grid grid-cols-2 gap-3">
            {amenities.map(({icon: Icon,label}) => <div key={label} className="flex min-h-28 flex-col justify-between rounded-[1.5rem] border border-black/7 bg-cream p-5 transition hover:-translate-y-1 hover:bg-white hover:shadow-card"><Icon size={21} className="text-sage"/><span className="mt-6 text-sm font-bold">{label}</span></div>)}
          </div>
        </Container>
      </section>

      <section className="bg-cream py-20 lg:py-28">
        <Container className="grid gap-8 lg:grid-cols-2 lg:items-center">
          <div className="overflow-hidden rounded-[2.2rem]"><img src="/images/hero.svg" className="h-[520px] w-full object-cover transition duration-700 hover:scale-[1.02]" alt="Terrazza privata"/></div>
          <div className="lg:pl-10">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-sun"><Sun size={25}/></div>
            <h2 className="section-title mt-6">La terrazza è una stanza in più, solo senza soffitto.</h2>
            <p className="mt-6 text-sm leading-8 text-ink/60">90 m² a uso esclusivo con zona lounge, tavolo da pranzo con gazebo, ombrellone, barbecue e lettini. Uno spazio raro a Roma, prezioso soprattutto nei soggiorni più lunghi.</p>
            <ul className="mt-7 grid gap-3 text-sm sm:grid-cols-2">{['Zona pranzo esterna','Area relax','Barbecue','Due lettini','Spazio anche per famiglie'].map(x => <li key={x} className="flex items-center gap-2 font-semibold"><Check size={16} className="text-sage"/>{x}</li>)}</ul>
            <Button to="/prenota" className="mt-8">Controlla le date</Button>
          </div>
        </Container>
      </section>

      <section className="py-20 lg:py-28"><Container><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{gallery.slice(1).map((x,i) => <img key={x.src} src={x.src} alt={x.alt} className={`w-full rounded-[1.8rem] object-cover ${i===0 ? 'h-96 lg:col-span-2' : 'h-72'}`}/>)}</div></Container></section>
    </>
  );
}
