import { Bus, Hospital, MapPinned, ShoppingBasket, TrainFront } from 'lucide-react';
import { Container } from '@/components/ui/Container';
import { Button } from '@/components/ui/Button';

const points = [
  { icon: Hospital, title: 'Policlinico Gemelli', text: 'Una delle destinazioni principali per chi sceglie D’Anzi House.' },
  { icon: Hospital, title: 'San Filippo Neri', text: 'Comodo per professionisti, pazienti e accompagnatori.' },
  { icon: TrainFront, title: 'Roma Balduina · FL3', text: 'Stazione ferroviaria raggiungibile a piedi dalla zona.' },
  { icon: Bus, title: 'Bus 46, 49, 546, 907', text: 'Diverse linee utili per muoversi verso il centro e i quartieri vicini.' },
  { icon: ShoppingBasket, title: 'Servizi quotidiani', text: 'Supermercati, farmacie, bar, ristoranti e negozi nel quartiere.' },
  { icon: MapPinned, title: 'Monte Mario', text: 'Una zona residenziale, autentica e più tranquilla del centro storico.' },
];

export function LocationPage() {
  return (
    <>
      <section className="py-16 lg:py-24">
        <Container>
          <p className="eyebrow">Roma · Monte Mario</p>
          <h1 className="display-title mt-4 max-w-5xl">Vicino a ciò che conta. Collegato a tutto il resto.</h1>
          <p className="mt-7 max-w-2xl text-base leading-8 text-ink/60">D’Anzi House si trova in Via Dego 4, in una zona residenziale con i servizi utili alla vita di tutti i giorni e collegamenti verso il centro di Roma.</p>
        </Container>
      </section>

      <section className="px-3 pb-10 sm:px-5">
        <div className="relative min-h-[500px] overflow-hidden rounded-[2rem] bg-cocoa sm:rounded-[2.6rem]">
          <div className="absolute -left-24 top-1/2 h-80 w-80 -translate-y-1/2 rounded-full bg-sage/30 blur-3xl" />
          <div className="absolute right-8 top-8 h-44 w-44 rounded-full bg-sun/30 blur-2xl" />
          <Container className="relative flex min-h-[500px] items-end pb-12 text-white">
            <div>
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-sun text-ink"><MapPinned size={25}/></div>
              <p className="mt-6 font-display text-4xl font-extrabold tracking-tight md:text-5xl">Via Dego 4 · 00168 Roma</p>
              <a className="mt-5 inline-flex rounded-full bg-white px-5 py-3 text-sm font-extrabold text-ink transition hover:-translate-y-0.5" href="https://www.google.com/maps/search/?api=1&query=Via+Dego+4+Roma" target="_blank" rel="noreferrer">Apri in Google Maps</a>
            </div>
          </Container>
        </div>
      </section>

      <section className="py-16 lg:py-24"><Container><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{points.map(({icon:Icon,title,text},i) => <article key={title} className={`rounded-[1.8rem] p-7 transition hover:-translate-y-1 ${i === 0 ? 'bg-sage text-white' : i === 1 ? 'bg-sun' : 'border border-black/7 bg-white'}`}><Icon size={23}/><h2 className="mt-10 font-display text-2xl font-extrabold tracking-tight">{title}</h2><p className={`mt-3 text-sm leading-7 ${i===0 ? 'text-white/75' : 'text-ink/60'}`}>{text}</p></article>)}</div><div className="mt-10 text-center"><Button to="/prenota">Verifica disponibilità</Button></div></Container></section>
    </>
  );
}
